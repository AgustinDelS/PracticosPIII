﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Practico2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //List<Persona> list = new List<Persona>
            //{
            //    new Persona { nombre = "Juan", edad = 25, ciudad = "Lima" },
            //    new Persona { nombre = "Maria", edad = 30, ciudad = "Bogota" },
            //    new Persona { nombre = "Pedro", edad = 35, ciudad = "Madrid" },
            //    new Persona { nombre = "Ana", edad = 20, ciudad = "Lima" },
            //    new Persona { nombre = "Jose", edad = 40, ciudad = "Buenos Aires" }

            //};

            //parte I
            //list.Where(x => x.edad >= 30 && x.ciudad == "Bogota").ToList().ForEach(x => Console.WriteLine(x.nombre));

            //parte II
            //list.Where(x => x.edad >= 25 && x.edad <= 30).OrderBy(x => x.edad).ToList().ForEach(x => Console.WriteLine(x.nombre));






            //EJERCICIO 2

            //ControlEmpresasEmpleados ce = new ControlEmpresasEmpleados();





            //Console.WriteLine("Promedio por empresas \n*************************************");
            //ce.promedioSalario();

            //Console.WriteLine("Peces gORDOS \n*************************************");
            //ce.getSeo("Desarrollador");
            //Console.WriteLine("");


            //Console.WriteLine("Plantilla \n*************************************");
            //ce.getEmpleadosOrdenados();
            //Console.WriteLine("");

            //Console.WriteLine("Plantilla ordenada por salario \n*************************************");
            //ce.getEmpleadosOrdenadosSegun();
            //Console.WriteLine("");

            //Console.WriteLine("FUNCTION getEmpleadosEmpresa \n*************************************");
            //ce.getEmpleadosEmpresa(2);


            //Console.ReadLine();


            // EJERCICIO 3
            //Complejidad cognitiva = 4
            // uno el bucle for, otro el if dentro del for, y se suma uno mas ya que hay un if dentro de un for. Por ultimo el ultimo foreach


            List<int> valores = new List<int>() { 7, 9, 3, 6, 5, 4, 1, 8, 2, };

            valores.OrderBy(n => n).ToList().ForEach(Console.WriteLine);



            //EJERCICIO 4
            //a)
            var sumaTotal = valores.Sum(n => n);
            Console.WriteLine($"La suma total es: {sumaTotal}");


            //b)
            var sumaTotalPares = valores.Where(n => n % 2 == 0).Sum();
            Console.WriteLine($"La suma total de los pares es: {sumaTotalPares}");


            //EJERCICIO 5

            List<int> valores2 = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };

            int sumaTotalBaloresParesMayoresAOcho = 0;
            int sumaTotalBaloresParesMenoresAOcho = 0;

            foreach (var item in valores2)
            {
                if (item % 2 == 0 && item > 8)
                {
                    sumaTotalBaloresParesMayoresAOcho += item;
                }
                else if (item % 2 == 0 && item < 8)
                {
                    sumaTotalBaloresParesMenoresAOcho += item;
                }
            }
            Console.WriteLine($"La suma total de los valores pares mayores a ocho es: {sumaTotalBaloresParesMayoresAOcho}");
            Console.WriteLine($"La suma total de los valores pares menores a ocho es: {sumaTotalBaloresParesMenoresAOcho}");


            imprimirSumas();


            //EJERCICIO 6

            //  La complejidad cognitiva es 6, ya que son 6 if separados

            Console.WriteLine("Ingrese una letra minuscula (desde a hasta f) para saber cual es la siguiente letra en el abecedario");
            char letra = Convert.ToChar(Console.ReadLine());

            if (letra >= 'a' && letra <= 'f')
            {
                char siguienteLetra = (char)(letra + 1);
                Console.WriteLine("La siguiente letra en el abecedario es: " + siguienteLetra);
            }
            else
            {
                Console.WriteLine("La letra ingresada no está en el rango correcto.");
            }


















            Console.ReadLine();
        }

        internal static void imprimirSumas()
        {
            List<int> valores = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };

            Console.WriteLine($"La suma de los pares > 8 = {valores.Where(x => x % 2 == 0 && x > 8).Sum(x => x)}");
            Console.WriteLine($"La suma de los pares < 8 = {valores.Where(x => x % 2 == 0 && x < 8).Sum(x => x)}");

        }

    }
}

